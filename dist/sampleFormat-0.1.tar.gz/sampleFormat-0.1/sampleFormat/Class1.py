class Class1:
	def printClass1():		
		print("This is class1")
