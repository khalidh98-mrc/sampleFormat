from Class1 import Class1
class Class2:
	def printClass2():
		print("This is class2")
Class1.printClass1()
